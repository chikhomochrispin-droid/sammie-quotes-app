
import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Share,
  Alert,
  StyleSheet,
  SafeAreaView,
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { Heart, Search, RefreshCw, Share2, Quote } from "lucide-react-native";

const aiWords = ["strength","success","focus","dreams","courage","growth","hope","discipline","future","power"];

function generateAIQuote() {
  const templates = [
    "Your {word} will shape your future.",
    "Greatness comes from {word} and patience.",
    "Never lose your {word} even in hard times.",
    "Success is built on {word}.",
    "Believe in your {word} every day.",
  ];
  const word = aiWords[Math.floor(Math.random() * aiWords.length)];
  const template = templates[Math.floor(Math.random() * templates.length)];
  return template.replace("{word}", word);
}

export default function App() {
  const [user, setUser] = useState(null);
  const [username, setUsername] = useState("");
  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState([]);
  const [aiQuote, setAIQuote] = useState(generateAIQuote());

  const baseQuotes = [
    { text: "Dream big and start small.", category: "Motivation" },
    { text: "Success begins with discipline.", category: "Success" },
    { text: "Love yourself first.", category: "Love" },
    { text: "Hard work beats talent.", category: "Success" },
  ];

  const allQuotes = useMemo(() => {
    return Array.from({ length: 1000 }, (_, i) => {
      const base = baseQuotes[i % baseQuotes.length];
      return {
        id: i + 1,
        text: `${base.text} #${i + 1}`,
        author: "Sammie Quotes",
      };
    });
  }, []);

  useEffect(() => {
    (async () => {
      const u = await AsyncStorage.getItem("user");
      const f = await AsyncStorage.getItem("fav");
      if (u) setUser(u);
      if (f) setFavorites(JSON.parse(f));
    })();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem("fav", JSON.stringify(favorites));
  }, [favorites]);

  const login = async () => {
    if (!username) return;
    setUser(username);
    await AsyncStorage.setItem("user", username);
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem("user");
  };

  const toggleFav = (id) => {
    setFavorites((p) =>
      p.includes(id) ? p.filter((x) => x !== id) : [...p, id]
    );
  };

  const share = async (text) => {
    await Share.share({ message: text });
  };

  const filtered = allQuotes.filter((q) =>
    q.text.toLowerCase().includes(search.toLowerCase())
  );

  if (!user) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.title}>Login</Text>
        <TextInput
          style={styles.input}
          placeholder="username"
          placeholderTextColor="gray"
          value={username}
          onChangeText={setUsername}
        />
        <TouchableOpacity style={styles.btn} onPress={login}>
          <Text style={{ color: "white" }}>Login</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Welcome {user}</Text>

      <TouchableOpacity onPress={logout}>
        <Text style={{ color: "red" }}>Logout</Text>
      </TouchableOpacity>

      <View style={styles.aiBox}>
        <Text style={{ color: "#a855f7" }}>AI Quote</Text>
        <Text style={{ color: "white" }}>{aiQuote}</Text>

        <TouchableOpacity
          style={styles.btn}
          onPress={() => setAIQuote(generateAIQuote())}
        >
          <Text style={{ color: "white" }}>New AI Quote</Text>
        </TouchableOpacity>
      </View>

      <TextInput
        style={styles.input}
        placeholder="Search"
        placeholderTextColor="gray"
        value={search}
        onChangeText={setSearch}
      />

      <FlatList
        data={filtered}
        keyExtractor={(i) => i.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <Text style={{ color: "white" }}>{item.text}</Text>

            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <TouchableOpacity onPress={() => toggleFav(item.id)}>
                <Heart color={favorites.includes(item.id) ? "red" : "white"} />
              </TouchableOpacity>

              <TouchableOpacity onPress={() => share(item.text)}>
                <Share2 color="white" />
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#0b0b1a", padding: 16 },
  title: { color: "white", fontSize: 22, marginBottom: 10 },
  input: { backgroundColor: "#1f1b3a", color: "white", padding: 10, marginVertical: 10 },
  btn: { backgroundColor: "#7c3aed", padding: 10, borderRadius: 8, marginTop: 10 },
  card: { backgroundColor: "#1f1b3a", padding: 10, marginVertical: 5 },
  aiBox: { backgroundColor: "#1f1b3a", padding: 10, marginBottom: 10 },
});
